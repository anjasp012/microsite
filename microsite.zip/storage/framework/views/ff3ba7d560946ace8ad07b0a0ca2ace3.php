<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row align-items-center" style="min-height: 100vh">
            <div class="col-12">
                <div class="row justify-content-center">
                    <div class="col-10 mb-5">
                        <div class="auth position-relative" style="padding: 8px">
                            <div class="bg-primary position-absolute rounded-3 top-0 start-0 bottom-0 end-0 rotate-2"
                                style="transform: rotate(1.5deg)"></div>
                            <div class="card rounded-3 border-0">
                                <div class="card-body">
                                    <div class="text-center mb-3">
                                        <img src="/images/masuk.png" class="w-50" alt="masuk">
                                    </div>
                                    <form method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="mb-2">
                                            <input id="email" type="username"
                                                class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
                                                value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus
                                                placeholder="Username">

                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-2">
                                            <input id="password" type="password"
                                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                                required autocomplete="current-password" placeholder="Password">

                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="remember"
                                                    id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('ingatkan saya')); ?>

                                                </label>
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-info w-100 mb-3 rounded-0 text-light fw-bold">
                                            Kirim
                                        </button>
                                        <div class="text-center">
                                            <small class="m-0 p-0 d-block">belum punya akun?</small>
                                            <a class="fw-bold text-decoration-none text-dark"
                                                href="<?php echo e(route('register')); ?>">
                                                Daftar di sini
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <a href="<?php echo e(route('home')); ?>"><img src="/images/kembali.png" width="20%" alt="kembali"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anjas\Sites\microsite\resources\views/auth/login.blade.php ENDPATH**/ ?>