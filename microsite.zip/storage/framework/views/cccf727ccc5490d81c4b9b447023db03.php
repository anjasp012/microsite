


<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Postingan Member')); ?></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="text-center">Rk</th>
                                        <th>Member</th>
                                        <th>Username</th>
                                        <th>Link Post</th>
                                        <th class="text-center">Point</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($no + 1); ?></td>
                                            <td>
                                                <?php echo e($post->member->username); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e($post->instagram); ?>"><?php echo e($post->instagram); ?></a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e($post->link); ?>"><?php echo e($post->link); ?></a>
                                            </td>
                                            <td class="text-center"><?php echo e($post->point); ?></td>
                                            <td>
                                                <?php if($post->status): ?>
                                                    <div class="badge text-bg-success">Sudah direview</div>
                                                <?php else: ?>
                                                    <div class="badge text-bg-danger">Belum direview</div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                    data-bs-target="#beriPoint<?php echo e($post->id); ?>">
                                                    Beri Skor
                                                </button>

                                                <!-- Modal -->
                                                <div class="modal fade" id="beriPoint<?php echo e($post->id); ?>" tabindex="-1"
                                                    aria-labelledby="beriPoint<?php echo e($post->id); ?>Label" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5"
                                                                    id="beriPoint<?php echo e($post->id); ?>Label">Beri Skor</h1>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form
                                                                action="<?php echo e(route('admin.postingan-member.update', $post->id)); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="modal-body">
                                                                    <div class="mb-0">
                                                                        <label for="point"
                                                                            class="form-label">point</label>
                                                                        <input type="number" required class="form-control"
                                                                            name="point" id="point"
                                                                            value="<?php echo e($post->point != 0 ? $post->point : ''); ?>">
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Batal</button>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Simpan</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.js">
    </script>

    <script>
        $(document).ready(function() {
            $('table').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anjas\Sites\microsite\resources\views/admin/post/index.blade.php ENDPATH**/ ?>